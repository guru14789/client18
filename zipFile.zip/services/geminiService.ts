import { GoogleGenAI, Type } from "@google/genai";
import { Language } from "../types";

export const translateQuestion = async (text: string, targetLanguage: Language): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Translate the following memory-sharing question into ${targetLanguage}. Keep the tone warm and conversational for a family setting. Output ONLY the translated text.\n\nQuestion: "${text}"`,
      config: {
        temperature: 0.7,
      },
    });

    return response.text.trim() || text;
  } catch (error) {
    console.error("Translation error:", error);
    return text;
  }
};

export const generateDocumentContext = async (filename: string, fileData?: string, mimeType?: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const prompt = `You are a warm, knowledgeable family historian. A user has uploaded a record named "${filename}". 
    ${fileData ? "Analyze the contents of this document." : "Based on the filename,"} 
    Write a warm, evocative 1-sentence description (max 20 words) explaining why this record is a treasure for future generations. 
    Focus on legacy, roots, and connection. Avoid generic phrases like "This document is".`;

    const parts: any[] = [{ text: prompt }];
    if (fileData && mimeType) {
      parts.unshift({
        inlineData: {
          data: fileData,
          mimeType: mimeType
        }
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts },
      config: {
        temperature: 0.8,
      },
    });

    return response.text.trim() || "A precious thread in the family tapestry, carefully preserved.";
  } catch (error) {
    console.error("Gemini summary error:", error);
    return "A tangible record of your family's journey, preserved for the generations to come.";
  }
};